package firstTP;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Exo3")
public class Exo3 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Login Form</h2>");
        out.println("<form action='Exo3' method='POST'>");
        out.println("<label for='username'>Username:</label>");
        out.println("<input type='text' id='username' name='username' required><br><br>");
        out.println("<label for='password'>Password:</label>");
        out.println("<input type='password' id='password' name='password' required><br><br>");
        out.println("<button type='submit'>Login</button>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if ("J2EE".equals(username) && "J2EE".equals(password)) {
            out.println("<html><body>");
            out.println("<h2>Welcome, " + username + "!</h2>");
            out.println("<form action='Exo2' method='GET'>");
            out.println("<label for='action'>Choose an action:</label>");
            out.println("<select name='action' id='action'>");
            out.println("<option value='GoogleSearch'>Google Search</option>");
            out.println("<option value='PageRedirect'>Page Redirect</option>");
            out.println("</select><br><br>");
            out.println("<label for='page'>Enter URL or search term:</label>");
            out.println("<input type='text' name='page' id='page' required><br><br>");
            out.println("<button type='submit'>Submit</button>");
            out.println("</form>");
            out.println("</body></html>");
        } else {
            out.println("<html><body>");
            out.println("<h2>Login Failed</h2>");
            out.println("<p>Invalid username or password. Please try again.</p>");
            out.println("</body></html>");
        }
    }
}
