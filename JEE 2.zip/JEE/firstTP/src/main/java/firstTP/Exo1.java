package firstTP;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Exo1")
public class Exo1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
    	
    	resp.setContentType("text/html");
    	resp.getWriter().println("<html><body>");
    	
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
    	
    	resp.getWriter().println("<b> hello world, this is my first servlet </b>");
        resp.getWriter().println("<p>Current Date and Time: " + formattedDateTime + "</p>");
    	
    	resp.getWriter().println("</html></body>");
  
    }
    	 

}