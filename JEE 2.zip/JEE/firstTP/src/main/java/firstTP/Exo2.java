package firstTP;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/Exo2")
public class Exo2 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String page = request.getParameter("page");

        if ("PageRedirect".equals(action) && page != null && page.startsWith("http")) {
            response.sendRedirect(page);
        } else if ("GoogleSearch".equals(action) && page != null && !page.isEmpty()) {
            String googleSearchUrl = "https://www.google.com/search?q=" + page;
            response.sendRedirect(googleSearchUrl);
        } else {
            response.setContentType("text/html");
            response.getWriter().println("Invalid parameters. Please specify a valid action and a page URL or search term.");
        }
    }
}
